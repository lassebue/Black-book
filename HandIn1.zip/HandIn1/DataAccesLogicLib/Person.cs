﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesLogicLib
{
    public class Person
    {
        public string FName { get; set; }
        public string SName { get; set; }
        public int id { get; set; }

        

    }
}
