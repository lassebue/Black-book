﻿CREATE TABLE PersonSb (
    PersonID       INT NOT NULL,
    FirstName      NVARCHAR(50) NOT NULL,
    SirName        NVARCHAR(50) NOT NULL,
CONSTRAINT pk_Person PRIMARY KEY CLUSTERED (PersonID))
GO
